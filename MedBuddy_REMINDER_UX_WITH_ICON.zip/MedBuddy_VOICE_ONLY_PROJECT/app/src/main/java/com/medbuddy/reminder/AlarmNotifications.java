package com.medbuddy.reminder;
import android.app.*;
import android.content.*;
import android.os.Build;
import androidx.core.app.NotificationCompat;

public class AlarmNotifications {
    public static final String CHANNEL="medbuddy_reminder_ui_v4";
    public static void createChannel(Context c) {
        if(Build.VERSION.SDK_INT>=26) {
            NotificationChannel ch=new NotificationChannel(CHANNEL,"MedBuddy medicine reminders",NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Tap to open the MedBuddy medicine reminder screen");
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            ch.setSound(null, null); // Voice-only: no device alarm tone.
            c.getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }
    public static void show(Context c,String id,String patient,String name,String dose,String foodTiming) {
        createChannel(c);
        Intent a=new Intent(c,AlarmActivity.class)
            .putExtra("id",id).putExtra("patient",patient).putExtra("name",name).putExtra("dose",dose).putExtra("foodTiming",foodTiming);
        a.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent full=PendingIntent.getActivity(c,id.hashCode(),a,
            PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b=new NotificationCompat.Builder(c,CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("💊 MEDICINE TIME")
            .setContentText(patient+": "+name+" "+dose+(foodTiming.isEmpty()?"":" • "+foodTiming))
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true).setAutoCancel(false)
            .setSilent(true)
            // Tapping the notification opens the branded in-app reminder screen.
            .setContentIntent(full)
            .setFullScreenIntent(full,true);
        c.getSystemService(NotificationManager.class).notify(id.hashCode(),b.build());
    }
    public static void cancel(Context c,String id) {
        c.getSystemService(NotificationManager.class).cancel(id.hashCode());
    }
}
