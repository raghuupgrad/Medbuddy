package com.medbuddy.reminder;
import android.content.*;
import org.json.JSONObject;

public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent i) {
        String id=i.getStringExtra("id");
        if(id==null)return;
        JSONObject o=ReminderStore.find(c,id);
        if(o==null)return;
        AlarmNotifications.show(c,id,o.optString("patient","Patient"),
            o.optString("name","Medicine"),o.optString("dose",""),o.optString("foodTiming",""));
        if(ReminderStore.sound(c)) {
            Intent voice=new Intent(c,AlarmVoiceService.class)
                .setAction(AlarmVoiceService.ACTION_START)
                .putExtra("patient",o.optString("patient","Patient"))
                .putExtra("name",o.optString("name","Medicine"))
                .putExtra("dose",o.optString("dose",""))
                .putExtra("foodTiming",o.optString("foodTiming",""));
            if(android.os.Build.VERSION.SDK_INT>=26) c.startForegroundService(voice);
            else c.startService(voice);
        }
        if("daily".equalsIgnoreCase(o.optString("frequency","daily")))
            AlarmScheduler.schedule(c,o);
    }
}
