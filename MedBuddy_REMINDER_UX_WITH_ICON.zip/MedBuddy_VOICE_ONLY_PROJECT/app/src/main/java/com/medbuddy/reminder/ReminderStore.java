package com.medbuddy.reminder;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

public class ReminderStore {
    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences("medbuddy_native", Context.MODE_PRIVATE);
    }
    public static JSONArray get(Context c) {
        try { return new JSONArray(p(c).getString("reminders", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }
    public static void save(Context c, JSONArray a) {
        p(c).edit().putString("reminders", a.toString()).apply();
    }
    public static boolean sound(Context c) { return p(c).getBoolean("sound", true); }
    public static void setSound(Context c, boolean enabled) {
        p(c).edit().putBoolean("sound", enabled).apply();
    }
    public static JSONObject find(Context c, String id) {
        JSONArray a=get(c);
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);
            if(o!=null && id.equals(o.optString("id"))) return o;
        }
        return null;
    }
    public static void remove(Context c, String id) {
        JSONArray a=get(c), b=new JSONArray();
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);
            if(o!=null && !id.equals(o.optString("id"))) b.put(o);
        }
        save(c,b);
    }
}
