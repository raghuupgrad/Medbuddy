package com.medbuddy.reminder;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Calendar;

public class AlarmScheduler {
    public static void sync(Context c) {
        JSONArray a=ReminderStore.get(c);
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);
            if(o!=null) schedule(c,o);
        }
    }
    public static void schedule(Context c, JSONObject o) {
        try {
            String id=o.optString("id"), t=o.optString("time");
            if(id.isEmpty() || t.isEmpty()) return;
            String[] hm=t.split(":");
            Calendar now=Calendar.getInstance(), at=Calendar.getInstance();
            at.set(Calendar.HOUR_OF_DAY,Integer.parseInt(hm[0]));
            at.set(Calendar.MINUTE,Integer.parseInt(hm[1]));
            at.set(Calendar.SECOND,0); at.set(Calendar.MILLISECOND,0);
            String start=o.optString("startDate","");
            if(!start.isEmpty()){
                String[] d=start.split("-");
                Calendar startCal=Calendar.getInstance();
                startCal.set(Integer.parseInt(d[0]),Integer.parseInt(d[1])-1,Integer.parseInt(d[2]),0,0,0);
                startCal.set(Calendar.MILLISECOND,0);
                if(now.before(startCal) && at.before(startCal))
                    at.set(startCal.get(Calendar.YEAR),startCal.get(Calendar.MONTH),startCal.get(Calendar.DAY_OF_MONTH));
            }
            if(!at.after(now)) at.add(Calendar.DAY_OF_YEAR,1);
            set(c,id,at.getTimeInMillis());
        } catch(Exception ignored) {}
    }
    public static void set(Context c,String id,long when) {
        Intent i=new Intent(c,AlarmReceiver.class).putExtra("id",id);
        PendingIntent pi=PendingIntent.getBroadcast(c,id.hashCode(),i,
            PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(am==null)return;
        if(Build.VERSION.SDK_INT>=31 && am.canScheduleExactAlarms())
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
        else if(Build.VERSION.SDK_INT>=23)
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
        else am.setExact(AlarmManager.RTC_WAKEUP,when,pi);
    }
    public static void cancel(Context c,String id) {
        Intent i=new Intent(c,AlarmReceiver.class);
        PendingIntent pi=PendingIntent.getBroadcast(c,id.hashCode(),i,
            PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(am!=null) am.cancel(pi);
        pi.cancel();
    }
}
