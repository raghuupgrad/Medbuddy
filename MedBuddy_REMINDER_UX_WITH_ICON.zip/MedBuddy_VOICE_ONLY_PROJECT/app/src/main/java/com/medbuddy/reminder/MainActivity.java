package com.medbuddy.reminder;
import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.webkit.*;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        AlarmNotifications.createChannel(this);
        web=new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        if(Build.VERSION.SDK_INT>=17) web.getSettings().setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new MainBridge(),"AndroidAlarmBridge");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        AlarmScheduler.sync(this);
        requestAndroidAccess();
    }
    private void requestAndroidAccess() {
        if(Build.VERSION.SDK_INT>=33 &&
            ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.POST_NOTIFICATIONS},101);
            return;
        }
        openNextSpecialAccess();
    }
    private void openNextSpecialAccess() {
        if(Build.VERSION.SDK_INT>=31) {
            AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
            if(am!=null && !am.canScheduleExactAlarms()) {
                try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:"+getPackageName()))); } catch(Exception ignored) {}
                return;
            }
        }
        if(Build.VERSION.SDK_INT>=34) {
            NotificationManager nm=getSystemService(NotificationManager.class);
            if(nm!=null && !nm.canUseFullScreenIntent()) {
                try { startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                    Uri.parse("package:"+getPackageName()))); } catch(Exception ignored) {}
            }
        }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==101) openNextSpecialAccess();
    }
    @Override protected void onResume() {
        super.onResume();
        // If the user returned from Android's special-access page, refresh scheduled alarms.
        AlarmScheduler.sync(this);
    }
    public class MainBridge {
        @JavascriptInterface public void syncReminders(String json) {
            try {
                JSONArray a=new JSONArray(json);
                JSONArray previous=ReminderStore.get(MainActivity.this);
                java.util.HashSet<String> keep=new java.util.HashSet<>();
                for(int i=0;i<a.length();i++) {
                    JSONObject o=a.optJSONObject(i);
                    if(o!=null) keep.add(o.optString("id"));
                }
                // Cancel native alarms and visible notifications for reminders deleted in the app.
                for(int i=0;i<previous.length();i++) {
                    JSONObject old=previous.optJSONObject(i);
                    if(old!=null) {
                        String oldId=old.optString("id");
                        if(!keep.contains(oldId)) {
                            AlarmScheduler.cancel(MainActivity.this,oldId);
                            AlarmNotifications.cancel(MainActivity.this,oldId);
                        }
                    }
                }
                ReminderStore.save(MainActivity.this,a);
                // Re-schedule all remaining reminders so edits to time/frequency take effect.
                for(int i=0;i<a.length();i++) {
                    JSONObject o=a.optJSONObject(i);
                    if(o!=null) AlarmScheduler.schedule(MainActivity.this,o);
                }
            } catch(Exception ignored) {}
        }
        @JavascriptInterface public void setSoundEnabled(boolean enabled) {
            ReminderStore.setSound(MainActivity.this,enabled);
        }
        @JavascriptInterface public boolean isSoundEnabled() {
            return ReminderStore.sound(MainActivity.this);
        }
        @JavascriptInterface public void openBatterySettings() {
            runOnUiThread(()->{
                try {
                    startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:"+getPackageName())));
                } catch(Exception e) {
                    try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); }
                    catch(Exception ignored) {}
                }
            });
        }
    }
}
