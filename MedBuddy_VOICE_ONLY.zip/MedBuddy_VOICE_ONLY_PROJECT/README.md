# MedBuddy — voice-only name and medicine reminder

This revision was inspected and changed specifically to remove the phone's default alarm ringtone.

## What the reminder says
The app speaks: "Reminder for [patient name]. It is time to take [medicine name]. [dose/instructions]."
It repeats the complete spoken reminder 3 seconds after the speech finishes.

## Sound behavior
- NO device alarm ringtone.
- NO beep or music.
- Notification channel is silent.
- A native Android foreground service runs TextToSpeech independently from the HTML screen, so spoken reminders do not depend solely on the WebView activity being visible.
- The previous purple MedBuddy HTML design and its animated mascot remain as the full-screen reminder interface.
- Sound ON/OFF controls whether the native speech service starts.

## Android permissions
Includes exact alarms, full-screen intent, notifications, boot completed, wake lock, battery optimization settings, and foreground-service permissions for speech playback.

## Build
Upload this ZIP as `MedBuddy_VOICE_ONLY.zip` to the GitHub repository root. Use the included `.github/workflows/build-apk.yml`.

## Device setup
Grant Notifications, Alarms & reminders / exact alarms and full-screen notification access. Set battery usage to Unrestricted if available. Make sure media/speech volume is audible. Text-to-speech requires an installed Android speech engine and a downloaded English (India) voice. If no voice is installed, install/configure Speech Services by Google in Android settings.

Full-screen presentation still depends on Android/OEM rules. If full-screen display is blocked, the notification with action buttons may appear instead, but the speech service is separately started by the alarm receiver.


Medicine reminders include an optional food instruction: Before food, After food, or With food. The selected instruction is shown on the reminder and spoken with the patient, medicine, and dose.


## Launcher icon
The Android launcher icon has been updated with the MedBuddy purple medicine-reminder mascot artwork.
