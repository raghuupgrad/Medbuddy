# MedBuddy – Medicine Reminder (GitHub Pages PWA)

## Included
- `index.html` – the medicine reminder app
- `manifest.json` – installable app metadata
- `service-worker.js` – offline app shell and notification click handling
- `icons/` – app icons (192×192 and 512×512)

## Publish on GitHub Pages
1. Create a new GitHub repository, for example `medbuddy`.
2. Upload **all files and folders** from this package. Keep `index.html` in the repository root.
3. Open the repository **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then Save.
6. Wait for GitHub Pages to publish. Open the Pages URL using Chrome on Android.
7. In Chrome, open the menu (⋮) and choose **Install app** or **Add to Home screen**.
8. Open MedBuddy, tap **Enable sound**, and allow notifications.

## Important Android/browser limitations
This is an installable Progressive Web App (PWA), not a native Android APK.
- Patient/tablet voice announcements repeat with a 3-second pause after each complete announcement, and the full-screen alarm page works while the app is open and the browser is allowed to run.
- Notifications can appear on the lock screen if Android notification and lock-screen permissions allow them.
- A normal web app cannot guarantee an exact-time alarm or force a full-screen screen takeover while the phone is locked, the app is force-closed, or Android has suspended it. Service workers are not reliable long-running timers.
- For dependable locked-screen alarms with native alarm-clock behaviour, the next step is a native Android app using Android AlarmManager and full-screen notification permissions.

## Reminder data
Reminders are stored in the browser's local storage on that device. Clearing Chrome/site data or uninstalling may remove them. This package does not sync reminders between devices.
