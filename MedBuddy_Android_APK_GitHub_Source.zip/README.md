# MedBuddy Android APK project

This is an Android WebView wrapper around the latest MedBuddy HTML reminder app.

## Build APK using GitHub Actions
1. Create a GitHub repository (public or private).
2. Upload the contents of this ZIP into the repository root. Keep the `.github` folder.
3. Open the **Actions** tab and enable Actions if GitHub asks.
4. The workflow named **Build MedBuddy APK** runs after pushing to `main`.
5. Open the completed workflow run, scroll to **Artifacts**, and download `MedBuddy-debug-apk`.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`, then install it on your Android phone. Allow installation from that source if Android asks.

## App details
- Package ID: `com.medbuddy.reminder`
- Minimum Android version: Android 6.0 (API 23)
- HTML app is stored at `app/src/main/assets/index.html`.
- App data uses WebView local storage on the device.

## Important reminder/alarm limitation
This APK wraps the HTML app in Android WebView. It does not yet implement native Android AlarmManager or native full-screen lock-screen alarm notifications. Browser JavaScript timers may not fire reliably after Android suspends or closes the app. For dependable alarms while locked or force-closed, a separate native alarm implementation is needed.

## Updating the HTML app
Replace `app/src/main/assets/index.html` with your updated HTML file, commit the change, and GitHub Actions will build a new APK.
