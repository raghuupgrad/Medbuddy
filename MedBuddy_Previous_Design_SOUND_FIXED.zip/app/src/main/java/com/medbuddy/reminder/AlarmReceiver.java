package com.medbuddy.reminder;
import android.content.*;
import org.json.JSONObject;

public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent i) {
        String id=i.getStringExtra("id");
        if(id==null)return;
        JSONObject o=ReminderStore.find(c,id);
        if(o==null)return;
        AlarmNotifications.show(c,id,o.optString("patient","Patient"),
            o.optString("name","Medicine"),o.optString("dose",""));
        if("daily".equalsIgnoreCase(o.optString("frequency","daily")))
            AlarmScheduler.schedule(c,o);
    }
}
