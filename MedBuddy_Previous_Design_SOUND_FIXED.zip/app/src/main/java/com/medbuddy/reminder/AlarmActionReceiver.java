package com.medbuddy.reminder;
import android.content.*;
import org.json.JSONObject;

public class AlarmActionReceiver extends BroadcastReceiver {
    public static final String DISMISS="com.medbuddy.reminder.DISMISS_ALARM";
    @Override public void onReceive(Context c,Intent i) {
        String id=i.getStringExtra("id");
        if(id==null)return;
        AlarmNotifications.cancel(c,id);
        Intent close=new Intent(DISMISS).setPackage(c.getPackageName()).putExtra("id",id);
        c.sendBroadcast(close);
        if("SNOOZE".equals(i.getAction())) {
            AlarmScheduler.set(c,id,System.currentTimeMillis()+5*60*1000L);
        } else if("TAKEN".equals(i.getAction())) {
            JSONObject o=ReminderStore.find(c,id);
            if(o!=null && "once".equalsIgnoreCase(o.optString("frequency","daily"))) {
                AlarmScheduler.cancel(c,id);
                ReminderStore.remove(c,id);
            }
        }
    }
}
