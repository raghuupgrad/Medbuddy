package com.medbuddy.reminder;
import android.app.*;
import android.content.*;
import android.media.*;
import android.net.Uri;
import android.os.*;
import android.speech.tts.*;
import android.view.*;
import android.webkit.*;
import org.json.JSONObject;
import java.util.*;

public class AlarmActivity extends Activity {
    private WebView web;
    private String id,patient,name,dose;
    private TextToSpeech tts;
    private Ringtone ringtone;
    private Handler handler=new Handler(Looper.getMainLooper());
    private boolean registered=false;
    private BroadcastReceiver dismissReceiver=new BroadcastReceiver() {
        @Override public void onReceive(Context c,Intent i) {
            if(id!=null && id.equals(i.getStringExtra("id"))) finishAlarm();
        }
    };
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        if(Build.VERSION.SDK_INT>=27) { setShowWhenLocked(true); setTurnScreenOn(true); }
        read(getIntent());
        web=new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.addJavascriptInterface(new AlarmBridge(),"AndroidAlarmBridge");
        setContentView(web);
        web.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView v,String url) {
                try {
                    JSONObject data=new JSONObject();
                    data.put("id",id); data.put("patient",patient); data.put("name",name); data.put("dose",dose);
                    v.evaluateJavascript("window.showNativeAlarm("+data.toString()+");",null);
                } catch(Exception ignored) {}
            }
        });
        web.loadUrl("file:///android_asset/index.html");
        registerReceiver(dismissReceiver,new IntentFilter(AlarmActionReceiver.DISMISS)); registered=true;
        startAlarmSoundAndSpeech();
    }
    private void read(Intent i) {
        id=i.getStringExtra("id"); patient=i.getStringExtra("patient");
        name=i.getStringExtra("name"); dose=i.getStringExtra("dose");
    }
    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i); setIntent(i); read(i);
        if(web!=null) {
            try {
                JSONObject d=new JSONObject(); d.put("id",id);d.put("patient",patient);d.put("name",name);d.put("dose",dose);
                web.evaluateJavascript("window.showNativeAlarm("+d.toString()+");",null);
            } catch(Exception ignored) {}
        }
        startAlarmSoundAndSpeech();
    }
    private void startAlarmSoundAndSpeech() {
        stopAudio();
        if(!ReminderStore.sound(this)) return;
        try {
            Uri alarm= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if(alarm==null) alarm=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            ringtone=RingtoneManager.getRingtone(this,alarm);
            if(ringtone!=null) {
                if(Build.VERSION.SDK_INT>=21) ringtone.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
                if(Build.VERSION.SDK_INT>=28) ringtone.setLooping(true);
                ringtone.play();
            }
        } catch(Exception ignored) {}
        tts=new TextToSpeech(this,status->{
            if(status==TextToSpeech.SUCCESS) {
                if(Build.VERSION.SDK_INT>=21) tts.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
                tts.setLanguage(new Locale("en","IN"));
                speakAnnouncement();
            }
        });
    }
    private void speakAnnouncement() {
        if(isFinishing() || tts==null || !ReminderStore.sound(this)) return;
        String words="Attention. "+(patient==null?"Patient":patient)+
            ". Your medicine is "+(name==null?"your medicine":name)+". "+
            (dose==null||dose.isEmpty()?"Please take your medicine now.":dose);
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String s) {}
            @Override public void onError(String s) { repeatAfterPause(); }
            @Override public void onDone(String s) { repeatAfterPause(); }
            private void repeatAfterPause() { handler.postDelayed(()->speakAnnouncement(),3000); }
        });
        tts.speak(words,TextToSpeech.QUEUE_FLUSH,null,"medbuddy_voice_alert");
    }
    private void stopAudio() {
        handler.removeCallbacksAndMessages(null);
        if(tts!=null) { tts.stop(); tts.shutdown(); tts=null; }
        if(ringtone!=null) { try { ringtone.stop(); } catch(Exception ignored) {} ringtone=null; }
    }
    private void finishAlarm() {
        stopAudio();
        if(web!=null) web.evaluateJavascript("window.dismissNativeAlarm && window.dismissNativeAlarm();",null);
        finish();
    }
    public class AlarmBridge {
        @JavascriptInterface public void snoozeFiveMinutes() {
            runOnUiThread(()->{
                AlarmScheduler.set(AlarmActivity.this,id,System.currentTimeMillis()+5*60*1000L);
                AlarmNotifications.cancel(AlarmActivity.this,id);
                finishAlarm();
            });
        }
        @JavascriptInterface public void medicineTaken() {
            runOnUiThread(()->{
                AlarmNotifications.cancel(AlarmActivity.this,id);
                JSONObject o=ReminderStore.find(AlarmActivity.this,id);
                if(o!=null && "once".equalsIgnoreCase(o.optString("frequency","daily"))) {
                    AlarmScheduler.cancel(AlarmActivity.this,id);
                    ReminderStore.remove(AlarmActivity.this,id);
                }
                finishAlarm();
            });
        }
        @JavascriptInterface public void syncReminders(String json) {}
        @JavascriptInterface public void setSoundEnabled(boolean enabled) { ReminderStore.setSound(AlarmActivity.this,enabled); }
        @JavascriptInterface public boolean isSoundEnabled() { return ReminderStore.sound(AlarmActivity.this); }
        @JavascriptInterface public void openBatterySettings() {}
    }
    @Override protected void onDestroy() {
        stopAudio();
        if(registered) try { unregisterReceiver(dismissReceiver); } catch(Exception ignored) {}
        if(web!=null) web.destroy();
        super.onDestroy();
    }
}
