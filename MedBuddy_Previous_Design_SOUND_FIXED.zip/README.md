# MedBuddy — previous HTML design with sound fix

This build preserves the previous purple HTML interface and the animated cartoon mascot.

## Root cause fixed
The previous Android notification channel explicitly used `setSound(null, null)`, which disabled notification sound. If Android did not launch the full-screen activity, the reminder could therefore be completely silent. This build creates a NEW channel ID (`medbuddy_alarm_channel_sound_v2`) with the device's default ALARM ringtone and alarm audio attributes. The new channel ID is intentional because Android does not let an app reliably change the sound of an already-created channel.

The full-screen alarm activity also plays the default alarm ringtone and repeats the spoken patient/medicine/dose announcement 3 seconds after speech finishes. The sound switch controls both.

## Permissions/access
Manifest includes SCHEDULE_EXACT_ALARM, USE_FULL_SCREEN_INTENT, POST_NOTIFICATIONS, RECEIVE_BOOT_COMPLETED, WAKE_LOCK, VIBRATE and REQUEST_IGNORE_BATTERY_OPTIMIZATIONS. First launch requests notification permission, then guides the user through exact-alarm and full-screen special access sequentially.

For best reliability, open Android Settings → Apps → MedBuddy → Battery and choose Unrestricted (wording varies by device). Keep the phone's alarm volume up and ensure the new MedBuddy notification channel has sound enabled.

## Build
Upload this ZIP to the repository root as `MedBuddy_Previous_Design_SOUND_FIXED.zip`. Use the included `.github/workflows/build-apk.yml`.

## Important
Android 14+ and some phone manufacturers may restrict full-screen notifications. If full-screen access is denied, the notification should still make its configured alarm sound and offer Snooze/Taken actions, but it may not automatically cover the lock screen. Test before relying on it for medication.
