# MedBuddy native Android project

This is the corrected native Android starter project for MedBuddy.

## Included Android permissions
- `SCHEDULE_EXACT_ALARM` — exact alarm access on Android 12+.
- `USE_FULL_SCREEN_INTENT` — full-screen alarm notifications on supported Android versions.
- `POST_NOTIFICATIONS` — notification permission on Android 13+.
- `RECEIVE_BOOT_COMPLETED` — restore reminders after reboot.
- `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` — optional battery settings shortcut.
- `WAKE_LOCK` — declared for alarm-related wake behavior.

## Build using GitHub Actions
Upload this ZIP to the root of your repository as `MedBuddy_Native_Android_With_Permissions.zip`.
The included `.github/workflows/build-apk.yml` extracts it, installs Android SDK API 35/build tools, builds the debug APK, and uploads it as an artifact.

## After installing
Open MedBuddy once and grant Notifications, Alarms & reminders / exact alarms, and full-screen notification access if Android offers those settings. For better reliability, set Settings → Apps → MedBuddy → Battery to Unrestricted if available. Keep the phone's alarm volume up.

## Limitations
Android or the device manufacturer may restrict background alarms or full-screen display. If exact-alarm or full-screen access is denied, behavior may be delayed or the notification may appear without opening over the lock screen. Test on the target device before relying on this for medication.
