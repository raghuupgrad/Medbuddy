package com.medbuddy.reminder;
import android.content.Context;
import org.json.JSONObject;
public class JSONObjectHelper {
    public static void markTaken(Context c,String id){
        JSONObject o=ReminderStore.find(c,id);
        if(o!=null && "once".equalsIgnoreCase(o.optString("repeat","daily"))){
            AlarmScheduler.cancel(c,id); ReminderStore.remove(c,id);
        }
    }
}
