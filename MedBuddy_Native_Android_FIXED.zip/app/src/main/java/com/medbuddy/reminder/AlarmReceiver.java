package com.medbuddy.reminder;
import android.content.*;
import org.json.JSONObject;

public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent i){
        String id=i.getStringExtra("id"); if(id==null)return;
        JSONObject o=ReminderStore.find(c,id); if(o==null)return;
        String patient=o.optString("patient",""), med=o.optString("medicine","Medicine"), dose=o.optString("dose","");
        AlarmNotifications.show(c,id,patient,med,dose);
        if("daily".equalsIgnoreCase(o.optString("repeat","daily"))) AlarmScheduler.schedule(c,o);
    }
}
