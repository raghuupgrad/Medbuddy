package com.medbuddy.reminder;
import android.Manifest;
import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.webkit.*;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.content.pm.PackageManager;

public class MainActivity extends Activity {
    WebView web;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        AlarmNotifications.channel(this);
        web=new WebView(this); web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(),"AndroidAlarmBridge");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        requestPermissionsAndSettings();
        AlarmScheduler.sync(this);
    }
    void requestPermissionsAndSettings(){
        if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.POST_NOTIFICATIONS},11);
        if(Build.VERSION.SDK_INT>=31){
            AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
            if(am!=null && !am.canScheduleExactAlarms()){
                try{ startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName()))); }catch(Exception ignored){}
            }
        }
        if(Build.VERSION.SDK_INT>=34){
            try{
                if(!getSystemService(NotificationManager.class).canUseFullScreenIntent())
                    startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,Uri.parse("package:"+getPackageName())));
            }catch(Exception ignored){}
        }
        // Battery optimization is surfaced as an optional user-controlled setting in the app.
    }
    public class Bridge {
        @JavascriptInterface public void syncReminders(String json,boolean sound){
            runOnUiThread(()->{
                try{
                    org.json.JSONArray a=new org.json.JSONArray(json);
                    ReminderStore.save(MainActivity.this,a,sound);
                    for(int x=0;x<a.length();x++){
                        org.json.JSONObject o=a.optJSONObject(x);
                        if(o!=null) AlarmScheduler.schedule(MainActivity.this,o);
                    }
                }catch(Exception ignored){}
            });
        }
        @JavascriptInterface public void setSoundEnabled(boolean enabled){ ReminderStore.setSound(MainActivity.this,enabled); }
        @JavascriptInterface public void openBatterySettings(){
            runOnUiThread(()->{
                try{
                    Intent x=new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,Uri.parse("package:"+getPackageName()));
                    startActivity(x);
                }catch(Exception e){
                    try{startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));}catch(Exception ignored){}
                }
            });
        }
    }
}
