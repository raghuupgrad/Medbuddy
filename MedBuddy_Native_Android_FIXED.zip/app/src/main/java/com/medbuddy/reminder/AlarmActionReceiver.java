package com.medbuddy.reminder;
import android.content.*;
import android.os.SystemClock;

public class AlarmActionReceiver extends BroadcastReceiver {
    public static final String DISMISS="com.medbuddy.reminder.DISMISS";
    @Override public void onReceive(Context c,Intent i){
        String id=i.getStringExtra("id"); if(id==null)return;
        AlarmNotifications.cancel(c,id);
        Intent done=new Intent(DISMISS).setPackage(c.getPackageName()).putExtra("id",id);
        c.sendBroadcast(done);
        if("SNOOZE".equals(i.getAction())) AlarmScheduler.set(c,id,System.currentTimeMillis()+5*60*1000L);
        else if("TAKEN".equals(i.getAction())){
            JSONObjectHelper.markTaken(c,id);
        }
    }
}
