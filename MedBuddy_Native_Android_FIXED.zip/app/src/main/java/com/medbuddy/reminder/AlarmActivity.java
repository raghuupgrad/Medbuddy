package com.medbuddy.reminder;
import android.app.*;
import android.content.*;
import android.graphics.Typeface;
import android.os.*;
import android.speech.tts.*;
import android.view.*;
import android.widget.*;
import android.media.AudioAttributes;
import java.util.*;

public class AlarmActivity extends Activity {
    TextToSpeech tts; Handler handler=new Handler(Looper.getMainLooper());
    String id,patient,medicine,dose; boolean speaking=false,receiverRegistered=false;
    Runnable repeatTask;
    BroadcastReceiver dismissReceiver=new BroadcastReceiver(){
        @Override public void onReceive(Context c,Intent i){ if(id!=null && id.equals(i.getStringExtra("id"))) finishAlarm(); }
    };
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().addFlags( android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
            android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
            android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
            android.view.WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        if(Build.VERSION.SDK_INT>=27){setShowWhenLocked(true);setTurnScreenOn(true);}
        read(getIntent()); buildUi();
        registerReceiver(dismissReceiver,new IntentFilter(AlarmActionReceiver.DISMISS)); receiverRegistered=true;
        startSpeech();
    }
    void read(Intent i){ id=i.getStringExtra("id"); patient=i.getStringExtra("patient"); medicine=i.getStringExtra("medicine"); dose=i.getStringExtra("dose"); }
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);read(i);buildUi();startSpeech();}
    void buildUi(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setGravity(Gravity.CENTER);root.setPadding(28,36,28,36);
        root.setBackgroundColor(0xFF102A43);
        TextView icon=new TextView(this);icon.setText("🤖💊");icon.setTextSize(64);icon.setGravity(Gravity.CENTER);
        root.addView(icon,new LinearLayout.LayoutParams(-1,-2));
        android.animation.ObjectAnimator pulse=android.animation.ObjectAnimator.ofFloat(icon,"scaleX",1f,1.12f,1f);
        pulse.setDuration(1100);pulse.setRepeatCount(-1);pulse.start();
        TextView title=new TextView(this);title.setText("MEDICINE TIME!");title.setTextColor(0xFFFFFFFF);title.setTextSize(28);title.setTypeface(null,Typeface.BOLD);title.setGravity(Gravity.CENTER);
        root.addView(title);
        TextView info=new TextView(this);info.setText((patient==null?"":patient+"\n")+(medicine==null?"Medicine":medicine)+(dose==null||dose.isEmpty()?"":"\n"+dose));
        info.setTextColor(0xFFFFFFFF);info.setTextSize(22);info.setGravity(Gravity.CENTER);info.setPadding(0,28,0,36);root.addView(info);
        Button snooze=new Button(this);snooze.setText("SNOOZE 5 MINUTES");root.addView(snooze,new LinearLayout.LayoutParams(-1,-2));
        snooze.setOnClickListener(v->{AlarmScheduler.set(this,id,System.currentTimeMillis()+300000);AlarmNotifications.cancel(this,id);finishAlarm();});
        Button taken=new Button(this);taken.setText("MEDICINE TAKEN");root.addView(taken,new LinearLayout.LayoutParams(-1,-2));
        taken.setOnClickListener(v->{AlarmNotifications.cancel(this,id);JSONObjectHelper.markTaken(this,id);finishAlarm();});
        setContentView(root);
    }
    void startSpeech(){
        if(!ReminderStore.sound(this))return;
        if(tts!=null){tts.stop();tts.shutdown();}
        tts=new TextToSpeech(this,status->{
            if(status==TextToSpeech.SUCCESS){
                if(Build.VERSION.SDK_INT>=21) tts.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
                tts.setLanguage(Locale.getDefault());
                speakAgain();
            }
        });
    }
    void speakAgain(){
        if(isFinishing()||tts==null)return;
        String message="Attention. "+(patient==null?"":patient)+". Your medicine is "+(medicine==null?"your medicine":medicine)+". "+(dose==null?"":dose);
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener(){
            @Override public void onStart(String s){}
            @Override public void onError(String s){}
            @Override public void onDone(String s){handler.postDelayed(()->speakAgain(),3000);}
        });
        tts.speak(message,TextToSpeech.QUEUE_FLUSH,null,"medbuddy_alarm_utterance");
    }
    void finishAlarm(){handler.removeCallbacksAndMessages(null);if(tts!=null){tts.stop();tts.shutdown();tts=null;}finish();}
    @Override protected void onDestroy(){if(receiverRegistered)try{unregisterReceiver(dismissReceiver);}catch(Exception ignored){};if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
