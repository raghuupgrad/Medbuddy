# MedBuddy native Android reminder project

This project replaces browser-only JavaScript timers with Android AlarmManager reminders.

## Included Android permissions
- `SCHEDULE_EXACT_ALARM`: requests exact alarm access on Android 12+.
- `USE_FULL_SCREEN_INTENT`: requests full-screen alarm notification access on Android 14+.
- `POST_NOTIFICATIONS`: asks notification permission on Android 13+.
- `RECEIVE_BOOT_COMPLETED`: restores scheduled reminders after reboot.
- `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`: supports the optional battery settings shortcut.
- `WAKE_LOCK`: declared for alarm-related wake behavior.

## User setup after installing
1. Open MedBuddy once.
2. Allow notifications.
3. Allow Alarms & reminders / exact alarms when Android asks.
4. Allow full-screen notifications if the device shows that setting.
5. For best reliability, open Settings → Apps → MedBuddy → Battery and select Unrestricted / Don't optimize where available.
6. Ensure the phone's alarm volume is turned up. Speech uses Android's alarm audio usage; it does not play music or beeps.

## Important platform limitations
Android and phone manufacturers can still restrict background execution. Full-screen display is controlled by Android's full-screen-intent policy and device settings; some Android versions or manufacturers may show a high-priority notification instead of launching over the lock screen. Exact alarms are exact only when the user grants the special access. If denied, the app uses an inexact idle-friendly fallback and the reminder may be delayed.

This is a starter native implementation. Test on the target phone and Android version before relying on it for critical medication.
