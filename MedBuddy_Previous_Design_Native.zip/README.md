# MedBuddy — previous HTML design + native Android alarm engine

This rebuild keeps the earlier polished purple MedBuddy HTML interface and its animated cartoon medicine mascot. The native Android alarm screen loads that same HTML page and opens its original full-screen reminder modal, so the visual experience matches the previous website rather than the replacement native mock-up.

## Alarm behavior
- Android AlarmManager schedules reminders even when the app's home screen is not open.
- Full-screen alarm notification can show the same previous HTML alarm modal over the lock screen when Android allows it.
- Default Android alarm ringtone plays while the alarm is active, with spoken patient name, medicine name and dose.
- Voice announcement repeats 3 seconds after each spoken announcement finishes.
- Snooze 5 minutes and Taken buttons are in the HTML alarm screen.
- Notification also has Snooze 5 min and Taken actions.
- Daily reminders are rescheduled for the next day; one-time reminders are removed when marked Taken.
- Sound ON/OFF controls both ringtone and speech.
- Reminder schedules restore after reboot.

## Android permissions/access
Manifest declares:
- SCHEDULE_EXACT_ALARM
- USE_FULL_SCREEN_INTENT
- POST_NOTIFICATIONS
- RECEIVE_BOOT_COMPLETED
- WAKE_LOCK
- REQUEST_IGNORE_BATTERY_OPTIMIZATIONS

On first launch the app requests notification permission and opens Android's exact-alarm and full-screen notification access screens when required. Use the Battery settings button in the app to open the battery optimization settings request. Set MedBuddy battery use to Unrestricted if your phone offers it.

## GitHub Actions
The included `.github/workflows/build-apk.yml` builds a debug APK. Upload this ZIP to the repository root as `MedBuddy_Previous_Design_Native.zip`, and use the included workflow.

## Important limitations
Full-screen presentation depends on Android's full-screen-intent access, lock-screen settings and manufacturer restrictions. Exact timing depends on exact-alarm access. Battery restrictions can delay delivery. The alarm ringtone uses the phone's alarm volume. If full-screen access is denied, Android may show the reminder notification with its action buttons instead. Test thoroughly on your device before relying on it for medication.
