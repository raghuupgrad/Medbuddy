package com.medbuddy.reminder;
import android.app.*;
import android.content.*;
import android.os.Build;
import androidx.core.app.NotificationCompat;

public class AlarmNotifications {
    public static final String CHANNEL="medbuddy_alarm_channel";
    public static void createChannel(Context c) {
        if(Build.VERSION.SDK_INT>=26) {
            NotificationChannel ch=new NotificationChannel(CHANNEL,"Medicine alarms",NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("MedBuddy full-screen medicine alarms");
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            ch.setSound(null,null); // Alarm sound is played by the full-screen alarm activity.
            c.getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }
    public static void show(Context c,String id,String patient,String name,String dose) {
        createChannel(c);
        Intent a=new Intent(c,AlarmActivity.class)
            .putExtra("id",id).putExtra("patient",patient).putExtra("name",name).putExtra("dose",dose);
        a.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent full=PendingIntent.getActivity(c,id.hashCode(),a,
            PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent si=new Intent(c,AlarmActionReceiver.class).setAction("SNOOZE").putExtra("id",id);
        Intent ti=new Intent(c,AlarmActionReceiver.class).setAction("TAKEN").putExtra("id",id);
        PendingIntent sp=PendingIntent.getBroadcast(c,id.hashCode()+1,si,
            PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        PendingIntent tp=PendingIntent.getBroadcast(c,id.hashCode()+2,ti,
            PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b=new NotificationCompat.Builder(c,CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("💊 MEDICINE TIME")
            .setContentText(patient+": "+name+" "+dose)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true).setAutoCancel(false)
            .setFullScreenIntent(full,true)
            .addAction(android.R.drawable.ic_media_pause,"Snooze 5 min",sp)
            .addAction(android.R.drawable.checkbox_on_background,"Taken",tp);
        c.getSystemService(NotificationManager.class).notify(id.hashCode(),b.build());
    }
    public static void cancel(Context c,String id) {
        c.getSystemService(NotificationManager.class).cancel(id.hashCode());
    }
}
