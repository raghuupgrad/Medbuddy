package com.medbuddy.reminder;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.HashSet;
import java.util.Set;

public class ReminderStore {
    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences("medbuddy_native", Context.MODE_PRIVATE);
    }
    public static JSONArray get(Context c) {
        try { return new JSONArray(p(c).getString("reminders", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }
    public static void save(Context c, JSONArray a) {
        p(c).edit().putString("reminders", a.toString())
            .putBoolean("reminders_initialized", true).apply();
    }
    public static boolean isInitialized(Context c) {
        return p(c).getBoolean("reminders_initialized", false);
    }
    public static boolean sound(Context c) { return p(c).getBoolean("sound", true); }
    public static void setSound(Context c, boolean enabled) {
        p(c).edit().putBoolean("sound", enabled).apply();
    }
    public static JSONObject find(Context c, String id) {
        JSONArray a=get(c);
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);
            if(o!=null && id.equals(o.optString("id"))) return o;
        }
        return null;
    }

    private static final String PENDING_KEY = "pending_reminder_ids";
    public static void markPending(Context c, String id) {
        Set<String> ids = new HashSet<>(p(c).getStringSet(PENDING_KEY, new HashSet<>()));
        ids.add(id);
        p(c).edit().putStringSet(PENDING_KEY, ids).apply();
    }
    public static boolean isPending(Context c, String id) {
        return p(c).getStringSet(PENDING_KEY, new HashSet<>()).contains(id);
    }
    public static void clearPending(Context c, String id) {
        Set<String> ids = new HashSet<>(p(c).getStringSet(PENDING_KEY, new HashSet<>()));
        ids.remove(id);
        p(c).edit().putStringSet(PENDING_KEY, ids).apply();
    }
    public static JSONArray pendingIds(Context c) {
        JSONArray a = new JSONArray();
        for (String id : p(c).getStringSet(PENDING_KEY, new HashSet<>())) a.put(id);
        return a;
    }
    public static void remove(Context c, String id) {
        clearPending(c,id);
        JSONArray a=get(c), b=new JSONArray();
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);
            if(o!=null && !id.equals(o.optString("id"))) b.put(o);
        }
        save(c,b);
    }
}
