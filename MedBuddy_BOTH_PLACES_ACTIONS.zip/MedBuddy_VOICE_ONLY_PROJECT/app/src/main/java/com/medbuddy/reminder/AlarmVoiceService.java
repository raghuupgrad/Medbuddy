package com.medbuddy.reminder;

import android.app.*;
import android.content.*;
import android.media.AudioAttributes;
import android.os.*;
import android.speech.tts.*;
import java.util.Locale;

public class AlarmVoiceService extends Service {
    public static final String ACTION_START="com.medbuddy.reminder.VOICE_START";
    public static final String ACTION_STOP="com.medbuddy.reminder.VOICE_STOP";
    private TextToSpeech tts;
    private Handler handler=new Handler(Looper.getMainLooper());
    private String patient="Patient", medicine="your medicine", dose="", foodTiming="";
    private boolean stopped=false;

    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        if(intent!=null && ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if(intent!=null) {
            patient=intent.getStringExtra("patient");
            medicine=intent.getStringExtra("name");
            dose=intent.getStringExtra("dose");
            foodTiming=intent.getStringExtra("foodTiming");
        }
        if(patient==null)patient="Patient";
        if(medicine==null)medicine="your medicine";
        if(dose==null)dose="";
        if(foodTiming==null)foodTiming="";
        startForeground(7401, buildSilentNotification());
        stopped=false;
        if(tts!=null){tts.stop();tts.shutdown();tts=null;}
        tts=new TextToSpeech(getApplicationContext(), status -> {
            if(status==TextToSpeech.SUCCESS && !stopped) {
                if(Build.VERSION.SDK_INT>=21) tts.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
                tts.setLanguage(new Locale("en","IN"));
                speak();
            }
        });
        return START_NOT_STICKY;
    }

    private Notification buildSilentNotification() {
        String channel="medbuddy_voice_service";
        if(Build.VERSION.SDK_INT>=26) {
            NotificationChannel ch=new NotificationChannel(channel,"Spoken medicine reminders",NotificationManager.IMPORTANCE_MIN);
            ch.setSound(null,null);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
        return new Notification.Builder(this,channel)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("MedBuddy spoken reminder")
            .setContentText("Speaking the patient and medicine name")
            .setOngoing(true).build();
    }

    private void speak() {
        if(stopped || tts==null)return;
        String message="Reminder for "+patient+". It is time to take "+medicine+". "+(dose.isEmpty()?"Please take your medicine now.":dose)+(foodTiming.isEmpty()?"":". Take it "+foodTiming);
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String id) {}
            @Override public void onError(String id) { repeat(); }
            @Override public void onDone(String id) { repeat(); }
            private void repeat(){ handler.postDelayed(()->speak(),3000); }
        });
        tts.speak(message,TextToSpeech.QUEUE_FLUSH,null,"medbuddy_voice_reminder");
    }

    @Override public void onDestroy() {
        stopped=true; handler.removeCallbacksAndMessages(null);
        if(tts!=null){tts.stop();tts.shutdown();tts=null;}
        super.onDestroy();
    }
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
