package com.medbuddy.reminder;
import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.webkit.*;
import org.json.JSONObject;

public class AlarmActivity extends Activity {
    private WebView web;
    private String id,patient,name,dose,foodTiming;

    private boolean registered=false;
    private BroadcastReceiver dismissReceiver=new BroadcastReceiver() {
        @Override public void onReceive(Context c,Intent i) {
            if(id!=null && id.equals(i.getStringExtra("id"))) finishAlarm();
        }
    };
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        if(Build.VERSION.SDK_INT>=27) { setShowWhenLocked(true); setTurnScreenOn(true); }
        applyImmersiveMode();
        read(getIntent());
        web=new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new AlarmBridge(),"AndroidAlarmBridge");
        setContentView(web);
        web.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView v,String url) {
                try {
                    JSONObject data=new JSONObject();
                    data.put("id",id); data.put("patient",patient); data.put("name",name); data.put("dose",dose); data.put("foodTiming",foodTiming);
                    v.evaluateJavascript("window.showNativeAlarm("+data.toString()+");",null);
                } catch(Exception ignored) {}
            }
        });
        web.loadUrl("file:///android_asset/index.html");
        IntentFilter filter=new IntentFilter(AlarmActionReceiver.DISMISS);
        if(Build.VERSION.SDK_INT>=33)
            registerReceiver(dismissReceiver,filter,Context.RECEIVER_NOT_EXPORTED);
        else
            registerReceiver(dismissReceiver,filter);
        registered=true;
    }
    private void applyImmersiveMode() {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            android.view.WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(android.view.WindowInsets.Type.statusBars() | android.view.WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_FULLSCREEN
            );
        }
    }
    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersiveMode();
    }
    private void read(Intent i) {
        id=i.getStringExtra("id"); patient=i.getStringExtra("patient");
        name=i.getStringExtra("name"); dose=i.getStringExtra("dose"); foodTiming=i.getStringExtra("foodTiming");
    }
    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i); setIntent(i); read(i);
        if(web!=null) {
            try {
                JSONObject d=new JSONObject(); d.put("id",id);d.put("patient",patient);d.put("name",name);d.put("dose",dose);d.put("foodTiming",foodTiming);
                web.evaluateJavascript("window.showNativeAlarm("+d.toString()+");",null);
            } catch(Exception ignored) {}
        }
    }
    private void finishAlarm() {
        stopVoiceService();
        if(web!=null) web.evaluateJavascript("window.dismissNativeAlarm && window.dismissNativeAlarm();",null);
        finish();
    }
    private void stopVoiceService() {
        stopService(new Intent(this,AlarmVoiceService.class));
    }
    public class AlarmBridge {
        @JavascriptInterface public void snoozeFiveMinutes() {
            runOnUiThread(()->{
                ReminderStore.clearPending(AlarmActivity.this,id);
                AlarmScheduler.set(AlarmActivity.this,id,System.currentTimeMillis()+5*60*1000L);
                AlarmNotifications.cancel(AlarmActivity.this,id);
                finishAlarm();
            });
        }
        @JavascriptInterface public void medicineTaken() {
            runOnUiThread(()->{
                AlarmNotifications.cancel(AlarmActivity.this,id);
                ReminderStore.clearPending(AlarmActivity.this,id);
                JSONObject o=ReminderStore.find(AlarmActivity.this,id);
                if(o!=null && "once".equalsIgnoreCase(o.optString("frequency","daily"))) {
                    AlarmScheduler.cancel(AlarmActivity.this,id);
                    ReminderStore.remove(AlarmActivity.this,id);
                }
                finishAlarm();
            });
        }
        @JavascriptInterface public void syncReminders(String json) {}
        @JavascriptInterface public void setSoundEnabled(boolean enabled) { ReminderStore.setSound(AlarmActivity.this,enabled); }
        @JavascriptInterface public boolean isSoundEnabled() { return ReminderStore.sound(AlarmActivity.this); }
        @JavascriptInterface public void openBatterySettings() {}
    }
    @Override protected void onDestroy() {
        stopVoiceService();
        if(registered) try { unregisterReceiver(dismissReceiver); } catch(Exception ignored) {}
        if(web!=null) web.destroy();
        super.onDestroy();
    }
}
