package com.medbuddy.reminder;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class AlarmScheduler {
    public static void sync(Context c) {
        JSONArray a=ReminderStore.get(c);
        for(int i=0;i<a.length();i++) {
            JSONObject o=a.optJSONObject(i);
            if(o!=null) schedule(c,o);
        }
    }

    public static void schedule(Context c, JSONObject o) {
        try {
            String id=o.optString("id");
            String time=o.optString("time");
            if(id.isEmpty() || time.isEmpty()) return;

            String[] hm=time.split(":");
            if(hm.length!=2) return;
            int hour=Integer.parseInt(hm[0]);
            int minute=Integer.parseInt(hm[1]);
            if(hour<0 || hour>23 || minute<0 || minute>59) return;

            Calendar now=Calendar.getInstance();
            Calendar today=Calendar.getInstance();
            today.set(Calendar.HOUR_OF_DAY,0);
            today.set(Calendar.MINUTE,0);
            today.set(Calendar.SECOND,0);
            today.set(Calendar.MILLISECOND,0);

            String frequency=o.optString("frequency","daily");
            String start=o.optString("startDate","");
            Calendar startDay=(Calendar)today.clone();
            if(!start.isEmpty()) {
                String[] d=start.split("-");
                if(d.length!=3) return;
                startDay.clear();
                startDay.set(Integer.parseInt(d[0]),Integer.parseInt(d[1])-1,
                    Integer.parseInt(d[2]),0,0,0);
            }

            Calendar at=(Calendar)today.clone();
            if(startDay.after(today)) at.setTimeInMillis(startDay.getTimeInMillis());
            at.set(Calendar.HOUR_OF_DAY,hour);
            at.set(Calendar.MINUTE,minute);
            at.set(Calendar.SECOND,0);
            at.set(Calendar.MILLISECOND,0);

            if("once".equalsIgnoreCase(frequency)) {
                // One-time reminders belong to their chosen date; never roll them to tomorrow.
                if(startDay.before(today) || !at.after(now)) {
                    cancel(c,id);
                    return;
                }
            } else {
                // Daily reminders begin on the selected start date and then repeat daily.
                if(!at.after(now)) at.add(Calendar.DAY_OF_YEAR,1);
            }
            set(c,id,at.getTimeInMillis());
        } catch(Exception ignored) {}
    }

    public static void set(Context c,String id,long when) {
        Intent i=new Intent(c,AlarmReceiver.class).putExtra("id",id);
        PendingIntent pi=PendingIntent.getBroadcast(c,id.hashCode(),i,
            PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(am==null) return;
        if(Build.VERSION.SDK_INT>=31 && am.canScheduleExactAlarms())
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
        else if(Build.VERSION.SDK_INT>=23)
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
        else
            am.setExact(AlarmManager.RTC_WAKEUP,when,pi);
    }

    public static void cancel(Context c,String id) {
        Intent i=new Intent(c,AlarmReceiver.class);
        PendingIntent pi=PendingIntent.getBroadcast(c,id.hashCode(),i,
            PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(am!=null) am.cancel(pi);
        pi.cancel();
    }
}
